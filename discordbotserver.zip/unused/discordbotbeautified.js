const Discord = require('discord.js');
const client = new Discord.Client();
//const ConsoleServer = require('./server.js');
const {
	prefix,
	token,
} = require('./config.json');

const fs = require('fs');
const net = require('net');
//const custom_console = require('./custom_console');
const log = console.log;

const Receiver = require('./receiver');
const Sender = require('./sender');
const tokens = require('./tokens');
const packets = require('./packets');
const {
	message
} = require('blessed');
const {
	lookup
} = require('dns');

const settings = JSON.parse(fs.readFileSync('settings.json'));

const server = net.createServer();

const delay = ms => new Promise(res => setTimeout(res, ms));

var servers = {};
var queue = [];
var previous = [];
var voters = [];

const userid = `${settings.id}`

const cooldown = new Set();
const votecooldown = new Set();

var endgamecalled = false
var gameinprogress = false
var autoplaylock = false

players = {} // Holds sockets that have gotten to the lobby
id = 0; // Increasing number that is used to assing IDs to players.

const STATES = {
	'LOBBY': 0,
	'PREPARING': 1,
	'PLAYING': 2,
};
state = STATES.LOBBY;

in_game_count = 0;

song = "";
folder = "";

voices_packet = null;
inst_packet = null;
chart_packet = null;

function play(message) {
	if (!fs.existsSync(`data/${queue[0].foldername}/${queue[0].songname}.json`)) {
		log(`Couldn't find 'data/${queue[0].foldername}/${queue[0].songname}.json'`);
		return;
	}
	song = queue[0].songname;
	folder = queue[0].foldername;
	log(`Set song to ${folder}/${song}`);
	if (previous.length < 1) {
		songprevious = "NONE"
	} else {
		songprevious = previous[0]
	}
	let q = ``;
	for (var i = 0; i < queue.length; i++) {
		q += `\n${i + 1}. **${queue[i].songname}**`;
	}
	let resp = [{
			name: `Server info`,
			value: `IP: ${settings.ip}\n PORT: ${settings.port}\n PASS: ${settings.showpass}`
		},
		{
			name: `Previous Song`,
			value: `${songprevious}`
		},
		{
			name: `Now Up`,
			value: `${song}`
		},
		{
			name: `:radio: Queue :radio:`,
			value: q
		},
	];

	//Putting it all together
	message.channel.send({
		embed: {
			title: 'SERVER',
			fields: resp,
			color: '#00FF00',
		}
	});
	seconds = settings.game_wait_time / 1000
	message.channel.send(`:alarm_clock:  ${song} will play in ${seconds} seconds :alarm_clock: `)

	setTimeout(function () {
		if (state == STATES.LOBBY) {
			if (!fs.existsSync(`data/${folder}/${song}.json`)) {
				log("Invalid song");
				autoplaylock = false;
				return;
			}
			if (Object.keys(players).length == 0) {
				log("No players joined");
				autoplaylock = false;
				return;
			}

			// Load the chart from file
			chart = fs.readFileSync('data/' + folder + '/' + song + '.json');
			let i = chart.length - 1;
			while (chart.readUInt8(i) != 125) {
				i--;
				// "LOL GOING THROUGH THE BULLSHIT TO CLEAN IDK WHATS STRANGE" - ninjamuffin99
			}


			chart = chart.slice(0, i + 1);
			gameinprogress = true
			message.channel.send(`:arrow_forward: Now Playing: ${song}`)

			if (queue.length > 0) {
				if (previous.length > 0) {
					previous.splice(0, 1)
				}
				previous.push(queue[0].songname)
			}

			queue.shift();

			var song_name = JSON.parse(chart).song.song.toLowerCase();

			chart_packet = Sender.CreatePacket(packets.SEND_CHART, [chart]);

			var voices_path = 'songs/' + song_name + '/Voices.ogg';
			var inst_path = 'songs/' + song_name + '/Inst.ogg'

			// Load the voices & inst from file
			// If they don't exists, a DENY packet will be sent when a player requests them
			voices_packet = null;
			if (fs.existsSync(voices_path))
				voices_packet = Sender.CreatePacket(packets.SEND_VOICES, [fs.readFileSync(voices_path)]);
			inst_packet = null;
			if (fs.existsSync(inst_path))
				inst_packet = Sender.CreatePacket(packets.SEND_INST, [fs.readFileSync(inst_path)]);

			// Tell all players that the game is starting
			broadcast(Sender.CreatePacket(packets.GAME_START, [song, folder]));
			state = STATES.PREPARING;


		} else {
			log("Game already in progress");
		}
	}, settings.game_wait_time);

	function checkifend() {
		if (endgamecalled == true) {
			if (queue[0]) {
				new play(message);
				endgamecalled = false;
			} else {
				log("all empty!");
				message.channel.send("The queue is empty so autoplay has stopped for now.")
				endgamecalled = false;
				autoplaylock = false;
			};
		};
	};
	setInterval(checkifend, 2000);
}

function create_player(socket, nickname) {
	var player = {
		'socket': socket,
		'id': id,
		'nickname': nickname,
		'ready': false,
		'alive': true,
	};
	socket.player = player;
	players[id] = player;
	id++;

	player.broadcast = function (buffer) {
		// Send message to all players but this one.
		for (let p of Object.values(players)) {
			if (p.id != player.id) {
				p.socket.write(buffer);
			}
		}
	}

	return player;
}

function broadcast(buffer) {
	// Send message to all players.
	for (let p of Object.values(players)) {
		p.socket.write(buffer);
	}
}

// Keep-Alive packets
setInterval(function () {
	for (let p of Object.values(players)) {
		// Loading the songs can take a while, and the client can't respond to keep-alives during that time.
		if (state == STATES.PREPARING && !p.ready)
			continue;
		// If the player hasn't responded to the keep-alive, destroy the connection.
		if (!p.alive)
			p.socket.destroy();
		p.alive = false;
	}
	// Send a new keep-alive packet
	broadcast(Sender.CreatePacket(packets.KEEP_ALIVE, []));
}, settings.keep_alive);

server.on('connection', function (socket) {
	var receiver = new Receiver(socket);


	receiver.on('data', function (packetId, data) {
		var socket = receiver.socket;
		var player = socket.player;

		switch (packetId) {
			// Setup
			case packets.SEND_CLIENT_TOKEN:
				var token = data[0];
				if (token == tokens.clientToken) { // Client's & server's tokens match
					socket.write(Sender.CreatePacket(packets.SEND_SERVER_TOKEN, [tokens.serverToken]));
					socket.verified = true;
				} else // Client's & server's tokens don't match
					socket.destroy()
				break;
			case packets.SEND_PASSWORD:
				var pwd = data[0];
				if (socket.verified && pwd == settings.password) {
					if (state != STATES.LOBBY) {
						socket.write(Sender.CreatePacket(packets.PASSWORD_CONFIRM, [1])); // Game already in progress
						socket.destroy();
						break;
					}
					// Authorized
					socket.authorized = true;
					socket.write(Sender.CreatePacket(packets.PASSWORD_CONFIRM, [0]));
				} else {
					socket.write(Sender.CreatePacket(packets.PASSWORD_CONFIRM, [2])); // Wrong password
					socket.destroy();
				}
				break;

				// Nickname / Lobby
			case packets.SEND_NICKNAME:
				if (socket.authorized) {
					var nick = data[0];


					if (nick == '' || /[^A-Za-z0-9.-]/.test(nick) || nick.length > 12) {
						socket.write(Sender.CreatePacket(packets.NICKNAME_CONFIRM, [3])); // Invalid nickname
						break;
					}

					for (p of Object.values(players)) {
						if (p.nickname == nick) {
							socket.write(Sender.CreatePacket(packets.NICKNAME_CONFIRM, [1])); // Nickname already claimed
							return;
						}
					}

					if (state != STATES.LOBBY) {
						socket.write(Sender.CreatePacket(packets.NICKNAME_CONFIRM, [2])); // Game already in progress
						break;
					}

					// Nickname accepted
					socket.nickname = nick;
					socket.write(Sender.CreatePacket(packets.NICKNAME_CONFIRM, [0]));
					break;
				}
				break;
			case packets.KEEP_ALIVE: // KEEP_ALIVE packet can be sent by server and client
				if (player)
					player.alive = true;
				break;
			case packets.JOINED_LOBBY:
				if (socket.nickname) {
					// Create player object for this player
					player = create_player(socket, socket.nickname);
					delete socket['nickname'];

					// Tell all players that this new player joined.
					player.broadcast(Sender.CreatePacket(packets.BROADCAST_NEW_PLAYER, [player.id, player.nickname]));
					// Tell this new player all the players that are already joined.
					for (let p of Object.values(players)) {
						if (p.id != player.id) {
							socket.write(Sender.CreatePacket(packets.BROADCAST_NEW_PLAYER, [p.id, p.nickname]));
						}
					}

					// This is used so that the player knows when the previous players are done being sent, and it knows it's own position in the list.
					socket.write(Sender.CreatePacket(packets.END_PREV_PLAYERS, []));
				}
				break;

				// Gaming
			case packets.GAME_READY:
				if (player && !player.ready && state == STATES.PREPARING) {
					player.ready = true;
					in_game_count++;

					// Tell everyone how many players are ready, for the "Waiting for players..." screen.
					broadcast(Sender.CreatePacket(packets.PLAYERS_READY, [in_game_count]));

					if (in_game_count == Object.keys(players).length) {
						// When all players are ready
						start_game();
					} else if (in_game_count == 1) {

						setTimeout(function () {
							// This code is dangerously close to terrible.
							// In practice, it's unlikely to cause issues.
							if (state == STATES.PREPARING) {
								dead_ids = [];
								for (let p of Object.values(players)) {
									if (!p.ready)
										dead_ids.push(p.id);
								}
								for (dead_id of dead_ids) {
									players[dead_id].socket.destroy();
								}

								start_game();
							}
						}, settings.wait);

					}
				}
				break;
			case packets.SEND_SCORE:
				if (player && state == STATES.PLAYING) {
					var score = data[0];
					// Broadcast score. Yeah, there's no server-side verification, too lazy to implement it... :/
					player.broadcast(Sender.CreatePacket(packets.BROADCAST_SCORE, [player.id, score]));
				}
				break;
			case packets.GAME_END:
				if (player && player.ready && state == STATES.PLAYING) {
					in_game_count--;
					player.ready = false;
					if (in_game_count == 0) {
						end_game();
					}
				}
				break;

				// Chat
			case packets.SEND_CHAT_MESSAGE:
				if (player) {
					var message = data[0];

					player.broadcast(Sender.CreatePacket(packets.BROADCAST_CHAT_MESSAGE, [player.id, message]));
				}
				break;

				// Download
			case packets.READY_DOWNLOAD:
				if (player && state == STATES.PREPARING)
					socket.write(chart_packet);
				break;
			case packets.REQUEST_VOICES:
				if (player && state == STATES.PREPARING) {
					if (voices_packet)
						socket.write(voices_packet);
					else {
						socket.write(Sender.CreatePacket(packets.DENY, []));
						// Give the client time to see the DENY packet
						setTimeout(function () {
							socket.destroy();
						}, 1000);
					}
				}
				break;
			case packets.REQUEST_INST:
				if (player && state == STATES.PREPARING) {
					if (inst_packet)
						socket.write(inst_packet);
					else {
						socket.write(Sender.CreatePacket(packets.DENY, []));
						// Give the client time to see the DENY packet
						setTimeout(function () {
							socket.destroy();
						}, 1000);
					}
				}
				break;

				// Error
			default:
				log("Wrong Packet ID from client " + player.id);
				socket.destroy();
				break;
		}
	});


	function client_leave() {
		var player = socket.player;

		if (player) {
			// Tell other players that this player just left.
			player.broadcast(Sender.CreatePacket(packets.PLAYER_LEFT, [player.id]));

			// If the only player that's yet to be ready leaves the server, start the game (or end it if this was the only player at all).
			if (in_game_count == Object.keys(players).length - 1 && !player.ready && state == STATES.PREPARING) {
				if (in_game_count > 0)
					start_game();
				else
					end_game();
			}

			if (player.ready) {
				in_game_count--;

				if (state == STATES.PLAYING) {
					// If the last player leaves, end the game.
					if (in_game_count == 0) {
						end_game();
					}
				}
			}

			// Remove the player object.
			delete players[player.id];

			broadcast(Sender.CreatePacket(packets.PLAYERS_READY, [in_game_count]));
		}
	}


	socket.on('error', function (e) {
		client_leave();
		socket.destroy();
	});


	socket.on('end', function () {
		client_leave();
	});
});

function start_game() {
	state = STATES.PLAYING;
	broadcast(Sender.CreatePacket(packets.EVERYONE_READY, [settings.safe_frames]));
}

function end_game() {
	state = STATES.LOBBY;
	for (p of Object.values(players)) {
		p.ready = false;
	}
	in_game_count = 0;
	log("Game finished");
	endgamecalled = true;
	gameinprogress = false;
}

server.on('listening', function () {
	log("Server started on port " + PORT);
});

server.maxConnections = 256;

const PORT = process.env.PORT || settings.port;
server.listen(PORT);

const commands = {
	"count": "Count the number of players online, and number or players that are ready",
	"list": "Display a list of IDs and player names",
	"autoplay": "Automatically plays the songs listed in queues",
	"info": "Sends the info for the server",
	"request": "Sends a request into the queue",
	"voteplay": "Vote to start the game",

	"exit": "Close the server",
};

client.once('ready', () => {
	console.log(`Bot is ready and its name is ${client.user.tag}`);
	client.user.setPresence({
		status: 'online',
		activity: {
			name: 'FNF Battle Royale',
			type: 'PLAYING',
		},
	});
});

client.on('message', message => {
	if (!message.content.startsWith(prefix) || message.author.bot) return;

	const args = message.content.slice(prefix.length).trim().split(' ');
	const command = args.shift().toLowerCase();

	if (command === `help`) {
		var help_string = "";
		for (const [cmd, desc] of Object.entries(commands)) {
			help_string += cmd + ": " + desc + "\n";
		}
		help_string = help_string.substr(0, help_string.length - 1);
		message.channel.send(help_string);
	} else if (command === `autoplay`) {
		if (message.author.id == userid) {

			if (autoplaylock == true) {
				message.channel.send("Autoplay is already running right now!");
				return;
			}

			if (!queue.length) {
				message.channel.send(":x: Theres no songs in the queue :x:");
				return;
			}
			play(message);
			autoplaylock = true
		} else {
			return;
		}
	} else if (command === `info`) {
		let q = ``;

		if (gameinprogress == true) {
			gamestatus = "CURRENTLY IN GAME"
		} else {
			gamestatus = "NOW OPEN"
		}

		if (previous.length < 1) {
			songprevious = "NONE"
		} else {
			songprevious = previous[0]
		}

		if (queue.length < 1) {
			nowup = "NONE"
		} else {
			nowup = queue[0].songname
		}

		if (queue.length > 0) {

			for (var i = 0; i < queue.length; i++) {
				q += `\n${i + 1}. **${queue[i].songname}**`;
			}
			let resp = [{
					name: `Server info`,
					value: `IP: ${settings.ip}\n PORT: ${settings.port}\n PASS: ${settings.showpass}`
				},
				{
					name: `Server Progress`,
					value: `${gamestatus}`
				},
				{
					name: `Previous Song`,
					value: `${songprevious}`
				},
				{
					name: `Up Next`,
					value: `${nowup}`
				},
				{
					name: `Host`,
					value: `${settings.host_name}`
				},
				{
					name: `:radio: Queue :radio:`,
					value: q
				},
			];

			//Putting it all together
			message.channel.send({
				embed: {
					title: 'SERVER',
					fields: resp,
					color: '#00FF00',
				}
			});
		}

		if (queue.length <= 0) {
			let resp = [{
					name: `Server info`,
					value: `IP: ${settings.ip}\n PORT: ${settings.port}\n PASS: ${settings.showpass}`
				},
				{
					name: `Server Progress`,
					value: `${gamestatus}`
				},
				{
					name: `Previous Song`,
					value: `${songprevious}`
				},
				{
					name: `Host`,
					value: `${settings.host_name}`
				},
			];

			//Putting it all together
			message.channel.send({
				embed: {
					title: 'SERVER',
					fields: resp,
					color: '#00FF00',
				}
			});
			return;
		}
	} else if (command === `skip`) {
		if (message.author.id == userid) {
			number = args[0] - 1
			queue.splice(number, 2)
		} else {
			return;
		}
	} else if (command === `showqueue`) {
		if (message.author.id == userid) {
			queueshow = JSON.stringify(queue)
			message.channel.send(queueshow)
		} else {
			return;
		}
	} else if (command === `remove`) {
		if (message.author.id == userid) {
			if (isNaN(args[0])) {
				message.channel.send("That is not a number");
				return;
			}

			if (queue.length <= 0) {
				message.channel.send("Theres no song to remove from the queue");
				return;
			}

			queuenumber = args[0] - 1
			queue.splice(queuenumber, 1)
			message.channel.send(`Removed song number ${args[0]} from the queue`)
		} else {
			return;
		}
	} else if (command === `voteremove`) {
		queuenumber = args[0] - 1

		if (votecooldown.has(message.author.id)) {
			message.channel.send("You're on a cooldown! Please wait a moment.")
			return;
		}

		if (isNaN(args[0])) {
			message.channel.send("That is not a number");
			return;
		}

		if (queue.length <= 0) {
			message.channel.send("Theres no song to remove from the queue");
			return;
		}

		if (queuenumber == 0) {
			message.channel.send("You cannot vote to remove this as its the upcoming song")
			return;
		}

		votecooldown.add(message.author.id);
		setTimeout(() => {
			votecooldown.delete(message.author.id);
		}, settings.cooldown); //Timeout for setted seconds

		const embedvote = new Discord.MessageEmbed()
			.setTitle('REMOVAL')
			.setDescription(`You're about to remove song number ${args[0]}`)
			.addField("Votes needed", `${settings.remove_vote_requirement}`)
			.setColor('RED')
		message.channel.send(embedvote).then(sentembed => {
			sentembed.react('💥')
			setTimeout(() => {
				getvotecount = sentembed.reactions.cache.get('💥').count;
				realvotecount = getvotecount - 1
				if (realvotecount >= settings.remove_vote_requirement) {
					queue.splice(queuenumber, 1)
					message.channel.send(`Removed song number ${args[0]} from the queue`)
				} else {
					message.channel.send("The removal request did not get enough votes, so it has been cancelled")
					return;
				}
			}, 10000)
		})

	} else if (command === `voteplay`) {

		if (autoplaylock == true) {
			message.channel.send("Autoplay is already running right now!");
			return;
		}

		if (!queue.length) {
			message.channel.send(":x: Theres no songs in the queue :x:");
			return;
		}

		if (voters.find(id => id == message.author.id))
			return;

		voters.push(message.author.id)

		if (voters.length != settings.vote_requirement) { // checks if the number of skips is setted votes or not
			message.delete();
			message.channel.send(settings.vote_requirement - voters.length + " more vote(s) to start the game") // sends the message saying how many more votes to start the game
		} else if (voters.length === settings.vote_requirement) {
			voters = []
			message.delete();
			message.channel.send("Starting game...")
			play(message);
			autoplaylock = true
			voters.length = 0
		}
		return;
	} else if (command === `request`) {

		if (cooldown.has(message.author.id)) {
			message.channel.send("You're on a cooldown! Please wait a moment.")
			return;
		} else {

			if (args.length < 2) {
				message.channel.send("Add in 'song-name' & 'song-folder'")
				return;
			}

			for (var i = 0; i < queue.length; i++) {
				if (args[1] == queue[i].foldername) {
					message.channel.send("That song is already in the queue!")
					return;
				}
			}

			if (!fs.existsSync(`data/${args[1]}/${args[0]}.json`)) {
				message.channel.send(`Couldn't find 'data/${args[1]}/${args[0]}.json'`);
				return;
			}

			cooldown.add(message.author.id);
			setTimeout(() => {
				cooldown.delete(message.author.id);
			}, settings.cooldown); //Timeout for setted seconds

			var info = {
				foldername: args[1],
				songname: args[0]
			};

			queue.push(info)

			const embed = new Discord.MessageEmbed()
			embed.setTitle("REQUEST SENT!")
			embed.setColor('#ff0059')
			embed.setDescription(`Your song has been added into the queue`)
			embed.addField('Song Name', `${args[0]}`)
			embed.addField('Song Folder', `${args[1]}`)
			message.channel.send(embed);
		}
	} else if (command === `exit`) {
		if (message.author.id == userid) {
			process.exit(1);
			return;
		} else {
			return;
		}
	} else if (command === `count`) {
		if (message.author.id == userid) {
			message.channel.send("Players: " + Object.keys(players).length + "\nReady Count: " + in_game_count);
			return;
		} else {
			return;
		}
	} else if (command === `list`) {
		if (message.author.id == userid) {
			var output = "";
			for (p of Object.values(players)) {
				output += p.id + ": " + p.nickname + "\n";
			}
			message.channel.send(output);
			return;
		} else {
			return;
		}
	}
});

client.login(token);