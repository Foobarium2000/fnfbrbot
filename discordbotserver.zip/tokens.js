var tokens = {};

tokens.clientToken = 93724324; // This shouldn't be changed.
tokens.serverToken = 67250746; // This should be changed when the server protocol changes.

module.exports = tokens;